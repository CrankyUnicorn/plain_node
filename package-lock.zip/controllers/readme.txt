
Controllers folder is used to store scripts that controle how routes io from the client-server is handle.